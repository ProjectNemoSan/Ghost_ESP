# Ghost ESP Press Kit

This folder contains resources that might be helpful if you're planning on making content about Ghost ESP.

## What is Ghost ESP?

Ghost ESP is an open-source firmware that transforms affordable ESP32 boards into versatile wireless security toolkits. It's an actively maintained fork of the original GhostESP project, built on ESP-IDF.

**Elevator pitch**: Ghost ESP brings professional-grade wireless security tooling to affordable ESP32 hardware, with a polished UI, broad device compatibility, and a thriving community.

## Core Capabilities

**Wi-Fi Testing**
- Deauthentication attacks, beacon spam, probe request logging
- Evil Portal (fake WiFi hotspot) with keylogging, WPA3 SAE flood, DHCP starvation
- Network scanning (AP detection, client monitoring, ARP/SSH/port scanning)

**Bluetooth (BLE)**
- AirTag spoofing, vendor-specific spam (Apple/Microsoft/Samsung/Google)
- BLE packet capture, RSSI tracking for selected and found Flipper Zeros
- BLE wardriving with GPS logging

**NFC**
- NTAG read/write (213/215/216) with NDEF parsing
- MIFARE Classic 1000+ key dictionary attacks
- Flipper Zero `.nfc` file export/import

**Infrared**
- Learn IR signals from remotes, decode received signals
- Transmit pre-programmed universal remote commands
- Flipper Zero IR file compatibility

**Bonus Features**
- GPS wardriving, Chromecast/DIAL device control, network printer output
- Customizable LED modes, mini-games

## Key Selling Points

- Runs on dozens of affordable ESP32 boards, from tiny wearables to full-screen dev kits.
- Manage everything from on-device menus, CLI or the Flipper Zero app.
- Backed by a large Discord community and frequent firmware updates.
- Designed to be a powerful educational tool that showcases real-world attack surfaces.

## High-Engagement Story Angles

- **"$10 vs $200 Hacking Gear"**: A comparison of similar features across consumer and pro devices.
- **"I Turned My ESP32 into a Wi-Fi Pineapple Detector"**: How Ghost ESP sniffs out rogue access points and Evil Twin setups.
- **"5GHz Wi-Fi Attacks with the ESP32-C5"**: Next-gen dual-band deauth, congestion monitoring, and Pineapple/Evil Twin detection alerts.
- **"ESP32 + Chameleon Ultra: The Ultimate NFC Toolkit?"**: How Ghost ESP can be used with a Chameleon Ultra to scan parse and save flipper zero compatible NFC tags.
- **"The Pocket-Sized Pentesting Tool You Need"**: How Ghost ESP can be used for researchers on the go.
- **"Setting Up a Keylogging Evil Portal in Minutes"**: How Ghost ESP can be used to set up a keylogging evil portal.
- **"Build a Universal Remote for $10"**: How Ghost ESP can be used to capture and edit and replay Flipper Zero ir files.

## Demo-Friendly Commands

- **`beaconspam -r`** — Flood the screen with fake SSIDs in real-time
- **`startportal default FreeWiFi`** — Launch an Evil Portal and capture credentials live
- **`karma start`** — Respond to device probes with fake networks automatically
- **`pineap`** — Detect rogue access points and Evil Twin setups
- **`blewardriving`** — GPS-logged BLE capture
- **`listenprobes`** — Show devices searching for networks 
- **`attack -d`** — Live deauthentication with real-time disconnections
- **`congestion`** — Display Wi-Fi channel congestion chart

## Reference Links
- GitHub repository (source, issues, changelog): https://github.com/jaylikesbunda/Ghost_ESP
- Online flasher: https://flasher.ghostesp.net
- Documentation: https://docs.ghostesp.net
- Community Discord: https://discord.gg/5cyNmUMgwh
- Merch Store: https://shop.ghostesp.net

## Contact & Attribution
- **Press/creator inquiries**: Use the Discord server channel, or message @jaylikesbunda on discord or @ghostesprevival on instagram.
- Please credit "GhostESP: Revival" and link to https://ghostesp.net or https://github.com/jaylikesbunda/Ghost_ESP in descriptions or footers.

## Legal & Responsible Use Reminder
Ghost ESP is an educational tool. Cover responsible usage, local laws, and consent-based testing in your content. Encourage viewers to practice ethical security research and respect privacy.
